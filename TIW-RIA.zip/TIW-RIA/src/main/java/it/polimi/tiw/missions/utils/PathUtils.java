package it.polimi.tiw.missions.utils;


public class PathUtils {


    public static String pathToHomePage = "/home.html";
    public static String pathToLoginPage = "/login.html";
  
}
