package it.polimi.tiw.missions.dao;

import java.sql.Connection;
import java.sql.Date;
import java.util.List;

import it.polimi.tiw.missions.beans.Document;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DocumentDAO {
	private Connection connection;

	public DocumentDAO() {
		// TODO Auto-generated constructor stub
	}

	public DocumentDAO(Connection con) {
		this.connection = con;
	}
	public List<Document> getDocumentsByIdFolder(int idfolder) throws SQLException{

		List<Document> documents = new ArrayList<>();
		String performedAction = " finding a document by idfolder";
		String query = "SELECT * FROM drive.document WHERE idfolder = ?";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, idfolder);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				Document document = new Document();
				document.setId(resultSet.getInt("id"));
				document.setName(resultSet.getString("name"));
				document.setIdFolder(resultSet.getInt("idfolder"));
				document.setDescription(resultSet.getString("description"));
				document.setType(resultSet.getString("type"));
				document.setDate(resultSet.getDate("date"));
				documents.add(document);
			}
			
		}catch(SQLException e) {
			throw new SQLException("Error accessing the DB when" + performedAction);
		}finally {
			try {
				resultSet.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the result set when" + performedAction);
			}
			try {
				preparedStatement.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the statement when" + performedAction);
			}
		}
		return documents;
	}
	public Document getDocumentById(int id) throws SQLException{

		Document document = null;
		String performedAction = " finding a document by id";
		String query = "SELECT * FROM drive.document WHERE id = ?";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, id);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				document = new Document();
				document.setId(resultSet.getInt("id"));
				document.setName(resultSet.getString("name"));
				document.setIdFolder(resultSet.getInt("idfolder"));
				document.setDescription(resultSet.getString("description"));
				document.setType(resultSet.getString("type"));
				document.setDate(resultSet.getDate("date"));
			}
			
		}catch(SQLException e) {
			throw new SQLException("Error accessing the DB when" + performedAction);
		}finally {
			try {
				resultSet.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the result set when" + performedAction);
			}
			try {
				preparedStatement.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the statement when" + performedAction);
			}
		}
		return document;
	}
	
	public void createDocument(String name, Date date,String description,String type,int idFolder) throws SQLException {
		String query = "insert into drive.document (name,date,description,type,idFolder) values (?,?,?,?,?)";
		try (PreparedStatement pstatement = connection.prepareStatement(query);) {
			pstatement.setString(1, name);
			pstatement.setDate(2, date);
			pstatement.setString(3, description);
			pstatement.setString(4, type);
			pstatement.setInt(5, idFolder);
			pstatement.executeUpdate();
		}
	}
	
	public void updateDocument(int id, int idFolder) throws SQLException {
		String query = "UPDATE drive.document SET idFolder = ? WHERE id = ? ";
		try (PreparedStatement pstatement = connection.prepareStatement(query);) {
			pstatement.setInt(1, idFolder);
			pstatement.setInt(2, id);
			pstatement.executeUpdate();
		}
	}
	
	public void deleteDocument(int idDocument) throws SQLException {
		String query3 = "delete from drive.document where id = ?";
		System.out.println("Query 3");
		try (PreparedStatement pstatement = connection.prepareStatement(query3);) {
			pstatement.setInt(1, idDocument);
			pstatement.executeUpdate();
		}
	}
}
