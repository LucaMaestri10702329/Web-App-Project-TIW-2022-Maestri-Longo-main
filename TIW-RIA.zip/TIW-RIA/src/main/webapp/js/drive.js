/**
 * Drive
 */
(function(){
    //Vars
    var userInfo, folderList, transferList, documentList;
    
    var pageOrchestrator = new PageOrchestrator();

    window.addEventListener("load", () => {
        pageOrchestrator.start(); // initialize the components
        pageOrchestrator.refresh(); // display initial content
    });
	function PageOrchestrator(){
        this.start = function(){
            //Init components
            userInfo = new UserInfo(
                sessionStorage.getItem('name'), 
                sessionStorage.getItem('id'), 
                [document.getElementById("userName"), document.getElementById("headerUserName")], 
                [document.getElementById("headerUserCode")], 
                document.getElementById("logout-button")
            );
             folderList = new FolderList(
                document.getElementById("create-account-form"), 
                document.getElementById("account-form-button"), 
                document.getElementById("create-account-warning"), 
                document.getElementById("create-account-button"), 
                document.getElementById("accounts"), 
                document.getElementById("accounts-message")
            );
            
            
            transferList = new TransferList(
                document.getElementById("account-details"),
                document.getElementById("account-name"),
                document.getElementById("account-code"),
                document.getElementById("account-balance"),
                document.getElementById("create-transfer-form"),
                document.getElementById("transfer-form-button"),
                document.getElementById("create-transfer-button"),
                document.getElementById("transfers"),
                document.getElementById("transfers-message")
            );
            
            documentList = new DocumentList(
                document.getElementById("document-details"),
                document.getElementById("document-name"),
                document.getElementById("account-code"),
                document.getElementById("account-balance"),
                document.getElementById("create-document-form"),
                document.getElementById("document-form-button"),
                document.getElementById("create-document-button"),
                document.getElementById("documents"),
                document.getElementById("documents-message")
            );
            
            
             
            
        };
        this.refresh = function(excludeContacts){
            //Refresh view
            userInfo.show();
            folderList.show();
           
        };
    }
    
    
    function UserInfo(
        _name, 
        _usercode, 
        nameElements, 
        codeElements, 
        _logout_button){ 

        this.name = _name;
        this.code = _usercode;
        this.logout_button = _logout_button;

        this.logout_button.addEventListener("click", e => {
            sessionStorage.clear();
        });

        this.show = function(){
            nameElements.forEach(element => {
                element.textContent = this.name;
            });
            codeElements.forEach(element => {
                element.textContent = this.code;
            });
        }
    }
    
    function FolderList(
        _create_account_form, 
        _account_form_button,
        _create_account_warning,
        _create_account_button,
        _accounts, 
        _accounts_message){

        this.create_account_form_div = _create_account_form;
        this.account_form_button = _account_form_button;
        this.create_account_warning = _create_account_warning;
        this.create_account_button = _create_account_button;
        this.accounts = _accounts;
        this.accounts_message = _accounts_message;

        this.currentSelectedId = NaN;
        this.last_used_open_button = null;
        this.account_names = [];

        var self = this; //Necessary only for in-function helpers (makeCall)
        //Link to buttons
        this.create_account_button.addEventListener('click', (e) =>{
            var button_label = e.target.textContent;
            if(button_label === 'Create account'){
                e.target.textContent = 'Hide form';
                self.create_account_warning.style.display = 'none';
                self.create_account_form_div.style.display='block';
            }else{
                e.target.textContent = 'Create account';
                self.create_account_form_div.style.display='none';
            }
        });

        this.account_form_button.addEventListener("click", (e) =>{

            self.create_account_warning.style.display = 'none';

            var create_account_form = e.target.closest("form");
            if(create_account_form.checkValidity()){
                
                var input_name = create_account_form.querySelector("input[name='accountName']");
                if(self.account_names.includes(input_name.value)){
                    create_account_form.reset();
                    self.create_account_warning.textContent = "Chosen account name already exists";
                    self.create_account_warning.style.display = 'block';
                    return;
                }

                makeCall("POST", 'CreateAccount', create_account_form, (req) =>{
                    switch(req.status){
                        case 200: //ok
                            var click = new Event("click");
                            self.create_account_button.dispatchEvent(click);
                            self.show();
                            break;
                        case 400: // bad request
                        case 401: // unauthorized
                        case 500: // server error
                            self.create_account_warning.textContent = req.responseText;
                            self.create_account_warning.style.display = 'block';
                            break;
                        default: //Error
                            self.create_account_warning.textContent = "Request reported status " + req.status;
                            self.create_account_warning.style.display = 'block';
                    }
                });
            }else{
                create_account_form.reportValidity();
            }
        });

        this.show = function(){
            //Request and update with the results
            makeCall("GET", 'GetAccounts', null, (req) =>{
                switch(req.status){
                    case 200: //ok
                        var accounts = JSON.parse(req.responseText);
                        self.update(accounts);
                        if(!isNaN(self.currentSelectedId)){
                            var open_account_button = document.querySelector("a[data_accountid='" + self.currentSelectedId + "']");
                            var click = new Event("click");
                            if(open_account_button)
                                open_account_button.dispatchEvent(click);
                        } 
                        break;
                    case 400: // bad request
                    case 401: // unauthorized
                    case 500: // server error
                        self.update(null, req.responseText);
                        break;
                    default: //Error
                        self.update(null, "Request reported status " + req.status);
                        break;
                }
            });
        };
        this.update = function(_accounts, _error) {
            
            self.accounts.style.display = "none";
            self.accounts.innerHTML = "";
            self.account_names.splice(0,self.account_names.length); //Clear array

            if(_error){

                self.accounts_message.textContent = _error;
                if(!self.accounts_message.className.includes("warning-message"))
                    self.accounts_message.className += " warning-message";
                self.accounts_message.style.display = "block";
                
            }else{

                if(_accounts.length === 0){
                    if(self.accounts_message.className.includes("warning-message"))
                        self.accounts_message.className.replace(" warning-message", "");
                    self.accounts_message.textContent = "You have no accounts in our bank :(";
                    self.accounts_message.style.display = "block";
                }else{
                    self.accounts_message.style.display = "none";
                    let card, card_title, card_data, b1, b2, br, open_button;
                    let i = 0;
                    _accounts.forEach((acc) => {
                        card = document.createElement("div");
                        card.className = "card card-blue";
                        if( i % 2 === 0)
                            card.className += " even";
                        card_title = document.createElement("div");
                        card_title.className = "card-title";
                        card_title.textContent = acc.name;
                        card.appendChild(card_title);
                        card_data = document.createElement("div");
                        card_data.className = "card-data";

                        b1 = document.createElement("b");
                        b1.textContent = "Code folder: ";
                        card_data.appendChild(b1);
                        card_data.appendChild(document.createTextNode(acc.id));
                    
                        br = document.createElement("br");
                        card_data.appendChild(br);

                        b2 = document.createElement("b");
                        b2.textContent = "Creation Date: ";
                        card_data.appendChild(b2);
                        card_data.appendChild(document.createTextNode(acc.date));
                

                        card.appendChild(card_data);
                        open_button = document.createElement("a");
                        open_button.className = "btn btn-purple btn-small btn-primary";
                        open_button.textContent = "Open";
                        open_button.setAttribute('data_accountid', acc.id);
                        open_button.addEventListener("click", (e) => {
                            if(e.target.textContent === "Open"){
                                if(self.last_used_open_button !== null){
                                    self.last_used_open_button.textContent = "Open";
                                }
                                e.target.textContent = "Hide";
                                self.last_used_open_button = e.target;
                                self.currentSelectedId = acc.id;
                                transferList.show(acc.id);
                            }else{
                                self.last_used_open_button = null;
                                self.currentSelectedId = NaN;
                                e.target.textContent = "Open";
                                transferList.hide();
                            }
                        });
                        card.appendChild(open_button);
                        self.account_names.push(acc.name);
                        self.accounts.appendChild(card);
                        i++;
                    });
                    self.accounts.style.display = "block";
                }
            }
        };
    }
    
    
    function TransferList(
                        _account_details,
                        _account_name, 
                        _account_code,
                        _account_balance, 
                        _create_transfer_form_div, 
                        _transfer_form_button,
                        _create_transfer_button,
                        _transfers, 
                        _transfers_message){
        //Saving vars
        this.account_details = _account_details;
        this.account_name_span = _account_name;
        this.account_code_span = _account_code;
        this.account_balance_span = _account_balance;
        this.create_transfer_form_div = _create_transfer_form_div;
        this.transfer_form_button = _transfer_form_button;
        this.create_transfer_button = _create_transfer_button;
        this.transfers = _transfers;
        this.transfers_message = _transfers_message;
        
        this.create_transfer_form = this.create_transfer_form_div.querySelector("form");
        this.dest_input = this.create_transfer_form.querySelector("input[name='name']");
        this.account_input = this.create_transfer_form.querySelector("input[name='destAccountId']");
        this.amount_input = this.create_transfer_form.querySelector("input[name='amount']");
        this.source_id = this.create_transfer_form.querySelector("input[name='sourceAccountId']");
        
        this.currentSelectedId = NaN;
        this.last_used_open_button = null;
        var self = this;
        
        //Attach listeners
        this.create_transfer_button.addEventListener("click", (e) => {
            if(this.create_transfer_button.textContent === 'Create transfer'){
                this.showCreate();
            }else{
                this.hideCreate(false); //Avoid resetting form
            }
        });
        this.transfer_form_button.addEventListener("click", (e) =>{
            //Get form
            if(this.create_transfer_form.checkValidity()){
                //Check account loop
                //Make request
                var self = this;
                makeCall("POST", 'MakeTransfer', this.create_transfer_form, (req) =>{
                    switch(req.status){
                        case 200: //ok
                           
                        case 400: // bad request
                        case 401: // unauthorized
                        case 500: // server error
                            break;
                        default: //Error
                    }
                });
            }
        });
        
        this.showCreate = function(){
            this.create_transfer_button.textContent = 'Hide form';
            this.create_transfer_form_div.style.display = 'block';
        };
        this.hideCreate = function(reset){
            this.create_transfer_button.textContent = 'Create transfer';
            this.create_transfer_form_div.style.display = 'none'; 
            if (reset)
                this.create_transfer_form.reset();
        };
        this.show = function(accountID){
            //Request and update with the results
            var self = this;
            makeCall("GET", 'GetAccountDetails?accountId=' + accountID, null, (req) =>{
                switch(req.status){
                    case 200: //ok
                        var data = JSON.parse(req.responseText);
                        self.update(data.folder, data.subfolders, false);
                        break;
                    case 400: // bad request
                    case 401: // unauthorized
                    case 500: // server error
                        self.update(null, req.responseText);
                        break;
                    default: //Error
                        self.update(null, "Request reported status " + req.status);
                        break;
                }
            });
        };
        this.hide = function(){
            this.account_details.style.display = "none";
            this.hideCreate(true); //Also reset form
        };
        this.update = function(account, transfers, error_message){
            //Hide content while refreshing
            this.hide();
            //Init headers
            this.account_name_span.textContent = account.name
            //Init message
            this.transfers_message.className = (error_message ? "warning-message" : "");
            this.transfers_message.style.display = (error_message || transfers.length === 0 ? "block" : "none");// invert order
            //Init hidden data
            this.source_id.value = account.id;


			
            //Clear content
            this.transfers.innerHTML = "";
            if (error_message){
                this.transfers_message.textContent = error_message;
                this.account_details.style.display = "block";
                return;
            }else if (transfers.length === 0){
                this.transfers_message.textContent = "You have no transfers for this account :(";
                this.account_details.style.display = "block";
                return;
            }
            
            //Init list   
            transfers.forEach((transfer) => {

                let card, card_title, card_data, b1, br, b2, amount_div;

                card = document.createElement("div");
                card.className = "linked-card linked-card-blue";

                card_title = document.createElement("div");
                card_title.className = "linked-card-title";
                card_title.textContent = (transfer.name);
                card.appendChild(card_title);
                
                card_data = document.createElement("div");
                card_data.className = "linked-card-data";
                
				b1 = document.createElement("b");
                b1.textContent = "Code folder: ";
                card_data.appendChild(b1);
                card_data.appendChild(document.createTextNode(transfer.id));
                
                br = document.createElement("br");
                card_data.appendChild(br);
                
                b1 = document.createElement("b");
                b1.textContent = "Data creation: ";
                card_data.appendChild(b1);
                card_data.appendChild(document.createTextNode(transfer.date));
                    
                br = document.createElement("br");
                card_data.appendChild(br);
				   open_button = document.createElement("a");
                        
                        open_button.textContent = "Open";
                        open_button.setAttribute("folderId",transfer.id);
                       	open_button.addEventListener("click", (e) => {
                            if(e.target.textContent === "Open"){
                                if(self.last_used_open_button !== null){
                                    self.last_used_open_button.textContent = "Open";
                                }
                                e.target.textContent = "Hide";
                                self.last_used_open_button = e.target;
                                
                                documentList.show(transfer.id);
                            }else{
                                self.last_used_open_button = null;
                             
                                e.target.textContent = "Open";
                                documentList.hide();
                            }
                        });
                card.appendChild(open_button);
                
                
                card.appendChild(card_data);

                this.transfers.appendChild(card);
            });
            this.account_details.style.display = "block";
        };
    }
     function DocumentList(
                        _account_details,
                        _account_name, 
                        _account_code,
                        _account_balance, 
                        _create_transfer_form_div, 
                        _transfer_form_button,
                        _create_transfer_button,
                        _transfers, 
                        _transfers_message){
        //Saving vars
        this.account_details = _account_details;
        this.account_name_span = _account_name;
        this.account_code_span = _account_code;
        this.account_balance_span = _account_balance;
        this.create_transfer_form_div = _create_transfer_form_div;
        this.transfer_form_button = _transfer_form_button;
        this.create_transfer_button = _create_transfer_button;
        this.transfers = _transfers;
        this.transfers_message = _transfers_message;
        
        this.create_transfer_form = this.create_transfer_form_div.querySelector("form");
        this.dest_input = this.create_transfer_form.querySelector("input[name='name']");
        this.account_input = this.create_transfer_form.querySelector("input[name='destAccountId']");
        this.amount_input = this.create_transfer_form.querySelector("input[name='amount']");
        this.source_id = this.create_transfer_form.querySelector("input[name='sourceAccountId']");
        
        this.currentSelectedId = NaN;
        this.last_used_open_button = null;
        var self = this;
        
        //Attach listeners
        this.create_transfer_button.addEventListener("click", (e) => {
            if(this.create_transfer_button.textContent === 'Create transfer'){
                this.showCreate();
            }else{
                this.hideCreate(false); //Avoid resetting form
            }
        });
        this.transfer_form_button.addEventListener("click", (e) =>{
            //Get form
            if(this.create_transfer_form.checkValidity()){
                //Check account loop
                //Make request
                var self = this;
                makeCall("POST", 'CreateDocument', this.create_transfer_form, (req) =>{
                    switch(req.status){
                        case 200: //ok
                           
                        case 400: // bad request
                        case 401: // unauthorized
                        case 500: // server error
                            break;
                        default: //Error
                    }
                });
            }
        });
        
        this.showCreate = function(){
            this.create_transfer_button.textContent = 'Hide form';
            this.create_transfer_form_div.style.display = 'block';
        };
        this.hideCreate = function(reset){
            this.create_transfer_button.textContent = 'Create transfer';
            this.create_transfer_form_div.style.display = 'none'; 
            if (reset)
                this.create_transfer_form.reset();
        };
        this.show = function(accountID){
            //Request and update with the results
            var self = this;
            makeCall("GET", 'GetDocuments?accountId=' + accountID, null, (req) =>{
                switch(req.status){
                    case 200: //ok
                        var data = JSON.parse(req.responseText);
                        self.update(data.folder, data.documents, false);
                        break;
                    case 400: // bad request
                    case 401: // unauthorized
                    case 500: // server error
                        self.update(null, req.responseText);
                        break;
                    default: //Error
                        self.update(null, "Request reported status " + req.status);
                        break;
                }
            });
        };
        this.hide = function(){
            this.account_details.style.display = "none";
            this.hideCreate(true); //Also reset form
        };
        this.update = function(account, transfers, error_message){
            //Hide content while refreshing
            this.hide();
            //Init headers
            this.account_name_span.textContent = account.name
            //Init message
            this.transfers_message.className = (error_message ? "warning-message" : "");
            this.transfers_message.style.display = (error_message || transfers.length === 0 ? "block" : "none");// invert order
            //Init hidden data
            this.source_id.value = account.id;


			
            //Clear content
            this.transfers.innerHTML = "";
            if (error_message){
                this.transfers_message.textContent = error_message;
                this.account_details.style.display = "block";
                return;
            }else if (transfers.length === 0){
                this.transfers_message.textContent = "You have no transfers for this account :(";
                this.account_details.style.display = "block";
                return;
            }
            
            //Init list   
            transfers.forEach((transfer) => {

                let card, card_title, card_data, b1, br, b2, amount_div;

                card = document.createElement("div");
                card.className = "linked-card linked-card-blue";

                card_title = document.createElement("div");
                card_title.className = "linked-card-title";
                card_title.textContent = (transfer.name);
                card.appendChild(card_title);
                
                card_data = document.createElement("div");
                card_data.className = "linked-card-data";

                b1 = document.createElement("b");
                b1.textContent = "Data creation: ";
                card_data.appendChild(b1);
                card_data.appendChild(document.createTextNode(transfer.date));
                
                br = document.createElement("br");
                card_data.appendChild(br);

	            b2 = document.createElement("b");
	            b2.textContent = "Description: ";
	            card_data.appendChild(b2);
	            card_data.appendChild(document.createTextNode(transfer.description));
                
                br = document.createElement("br");
            	card_data.appendChild(br);

                b2 = document.createElement("b");
                b2.textContent = "Type: ";
                card_data.appendChild(b2);
                card_data.appendChild(document.createTextNode(transfer.type));
                
                
				  
                
                
                card.appendChild(card_data);

                this.transfers.appendChild(card);
            });
            this.account_details.style.display = "block";
        };
    }

     
    
})(); 