-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: drive
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userId_idx` (`userId`),
  CONSTRAINT `userId` FOREIGN KEY (`userId`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `Description` varchar(45) DEFAULT NULL,
  `Type` varchar(45) DEFAULT NULL,
  `idFolder` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idFolder_idx` (`idFolder`),
  CONSTRAINT `idFolder` FOREIGN KEY (`idFolder`) REFERENCES `folder` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
INSERT INTO `document` VALUES (4,'relazione','2022-07-26','progetto2022','pdf',2),(5,'relazione','2022-07-26','progetto2022','pdf',31),(7,'document2','2000-01-03','testCreation','pdf',8),(8,'Italia','1946-06-02','FondazioneItalia','pdf',9),(9,'risultati','2022-06-01','testRisultati','pdf',18),(10,'testGeografiaID','2022-01-01','test','pdf',9),(11,'Relazione','2022-06-21','Relazione progetto','pdf',21),(12,'documentData','2022-07-28','testCreation','pdf',23),(13,'testRiaDocument','2022-07-30','test','pdf',8),(14,'testRiaFolderLuca','2022-07-30','testRia','pdf',8),(15,'Risultati_appello_2','2022-07-30','Voti pessimi','pdf',18),(16,'test2','2022-07-31','testForDelete','pdf',46),(17,'pradelletorri','2022-07-31','test','pdf',43);
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder`
--

DROP TABLE IF EXISTS `folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `folder` (
  `id` int NOT NULL AUTO_INCREMENT,
  `idUser` int DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userId_idx` (`idUser`),
  CONSTRAINT `idUser` FOREIGN KEY (`idUser`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder`
--

LOCK TABLES `folder` WRITE;
/*!40000 ALTER TABLE `folder` DISABLE KEYS */;
INSERT INTO `folder` VALUES (1,1,'tiw','2022-07-26'),(2,1,'project','2022-07-26'),(4,2,'pellegrini','2022-06-15'),(6,2,'delfino','2022-01-02'),(8,1,'luca','2000-01-03'),(9,1,'geografia','2000-01-02'),(11,1,'Geografia','2006-03-01'),(12,2,'campionessa','2016-07-12'),(13,5,'Gold','2009-12-02'),(14,5,'barcelona','2000-01-02'),(15,2,'stileLibero','2000-02-01'),(16,1,'testUser','2000-01-20'),(17,1,'TestSubfolder','2022-02-01'),(18,1,'esame','2022-07-18'),(19,6,'TIW','2022-02-01'),(20,6,'Meccanica','2022-02-24'),(21,6,'PureHtml','2022-02-01'),(22,1,'testDate','2022-07-28'),(23,1,'testDate2','2022-07-28'),(24,1,'TestActualDate','2022-07-28'),(25,1,'testData2','2022-07-28'),(26,1,'testDate2','2022-07-28'),(27,1,'TestRia','2022-07-29'),(28,1,'testRia2','2022-07-29'),(29,1,'testRIA3','2022-07-29'),(30,1,'testRia4','2022-07-29'),(31,1,'testRia','2022-07-29'),(32,1,'testRia','2022-07-29'),(33,1,'testPopup','2022-07-29'),(34,1,'test','2022-07-29'),(35,1,'test2','2022-07-29'),(36,1,'1','2022-07-29'),(37,1,'4','2022-07-29'),(38,1,'1','2022-07-29'),(39,1,'testCartella','2022-07-29'),(40,1,'storia','2022-07-29'),(41,1,'italiano','2022-07-29'),(42,1,'errore','2022-07-29'),(43,2,'stileRana','2022-07-29'),(44,10,'pallavolo','2022-07-29'),(45,10,'barianoVolley','2022-07-29'),(46,1,'boh','2022-07-29'),(47,1,'Dinamica del veicolo','2022-07-29'),(48,1,'1','2022-07-29'),(49,11,'testFolder','2022-07-30'),(50,11,'testSubfolder','2022-07-30'),(51,1,'testRecharge','2022-07-31'),(52,1,'testRecharge2','2022-07-31'),(53,1,'test2','2022-07-31'),(55,1,'testRecharheSub','2022-07-31');
/*!40000 ALTER TABLE `folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subfolder`
--

DROP TABLE IF EXISTS `subfolder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subfolder` (
  `idsubfolder` int NOT NULL,
  `idFather` int DEFAULT NULL,
  PRIMARY KEY (`idsubfolder`),
  KEY `idFather_idx` (`idFather`),
  CONSTRAINT `idFather` FOREIGN KEY (`idFather`) REFERENCES `folder` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `idSubFolder` FOREIGN KEY (`idsubfolder`) REFERENCES `folder` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subfolder`
--

LOCK TABLES `subfolder` WRITE;
/*!40000 ALTER TABLE `subfolder` DISABLE KEYS */;
INSERT INTO `subfolder` VALUES (2,1),(8,1),(12,1),(17,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(42,1),(48,1),(51,1),(52,1),(53,1),(55,1),(9,2),(40,2),(41,2),(15,4),(43,4),(14,13),(22,16),(23,16),(21,19),(26,25),(45,44),(50,49);
/*!40000 ALTER TABLE `subfolder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `pwd` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'luca','luca','luca@gmail.com'),(2,'clara','clara','clara@gmail.com'),(3,'paulo','paulo','paulo@gmail.com'),(4,'maestri','maestri','maestri@gmail.com'),(5,'messi','messi','messi@gmail.com'),(6,'Virginia','virginia','virginia@gmail.com'),(7,'ronaldo','ronaldo','ronaldo@gmail.com'),(8,'elena','elena','elena@gmail.com'),(9,'dusan','dusan','dusan@gmail.com'),(10,'elisa','elisa','elisa@gmail.com'),(11,'silvia','silvia','silvia@gmail.com');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02  9:37:16
