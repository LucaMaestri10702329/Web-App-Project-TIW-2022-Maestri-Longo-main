package it.polimi.tiw.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import it.polimi.tiw.beans.User;


public class UserDAO {

	private Connection connection;
	public UserDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public UserDAO(Connection con) {
		this.connection = con;
	}
	
	public User findUser(String email, String password) throws SQLException{

		User user = null;
		String performedAction = " finding a user by email and password";
		String query = "SELECT * FROM drive.user WHERE email = ? AND pwd = ?";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, email);
			preparedStatement.setString(2, password);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				user = new User();
				user.setId(resultSet.getInt("id"));
				user.setName(resultSet.getString("name"));
				user.setEmail(resultSet.getString("email"));
			}
			
			
		}catch(SQLException e) {
			throw new SQLException("Error accessing the DB when" + performedAction);
		}finally {
			try {
				resultSet.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the result set when" + performedAction);
			}
			try {
				preparedStatement.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the statement when" + performedAction);
			}
		}
		return user;
	}
	
public void registerUser(String name, String email, String password) throws SQLException {
		
		String performedAction = " registering a new user in the database";
		String queryAddUser = "INSERT INTO drive.user (name,email,pwd) VALUES(?,?,?)";
		PreparedStatement preparedStatementAddUser = null;	
		
		try {
			
			preparedStatementAddUser = connection.prepareStatement(queryAddUser);
			preparedStatementAddUser.setString(1, name);
			preparedStatementAddUser.setString(2, email);
			preparedStatementAddUser.setString(3, password);
			preparedStatementAddUser.executeUpdate();
			
		}catch(SQLException e) {
			throw new SQLException("Error accessing the DB when" + performedAction);
		}finally {
			try {
				preparedStatementAddUser.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the statement when" + performedAction);
			}
		}
	}
public User getUserByEmail(String email) throws SQLException{

	User user = null;
	String performedAction = " finding a user by email";
	String query = "SELECT * FROM drive.user WHERE email = ?";
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	
	try {
		preparedStatement = connection.prepareStatement(query);
		preparedStatement.setString(1, email);
		resultSet = preparedStatement.executeQuery();
		
		while(resultSet.next()) {
			user = new User();
			user.setId(resultSet.getInt("id"));
			user.setName(resultSet.getString("name"));
			user.setEmail(resultSet.getString("email"));
		}
		
	}catch(SQLException e) {
		throw new SQLException("Error accessing the DB when" + performedAction);
	}finally {
		try {
			resultSet.close();
		}catch (Exception e) {
			throw new SQLException("Error closing the result set when" + performedAction);
		}
		try {
			preparedStatement.close();
		}catch (Exception e) {
			throw new SQLException("Error closing the statement when" + performedAction);
		}
	}
	return user;
}
public User getUserById(int id) throws SQLException{

	User user = null;
	String performedAction = " finding a user by id";
	String query = "SELECT * FROM drive.user WHERE id = ?";
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	
	try {
		preparedStatement = connection.prepareStatement(query);
		preparedStatement.setInt(1, id);
		resultSet = preparedStatement.executeQuery();
		
		while(resultSet.next()) {
			user = new User();
			user.setId(resultSet.getInt("id"));
			user.setName(resultSet.getString("name"));
			user.setEmail(resultSet.getString("email"));
		}
		
	}catch(SQLException e) {
		throw new SQLException("Error accessing the DB when" + performedAction);
	}finally {
		try {
			resultSet.close();
		}catch (Exception e) {
			throw new SQLException("Error closing the result set when" + performedAction);
		}
		try {
			preparedStatement.close();
		}catch (Exception e) {
			throw new SQLException("Error closing the statement when" + performedAction);
		}
	}
	return user;
}
}
