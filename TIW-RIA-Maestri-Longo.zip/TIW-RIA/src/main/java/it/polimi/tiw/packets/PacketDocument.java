package it.polimi.tiw.packets;

import java.util.List;

import it.polimi.tiw.beans.Document;
import it.polimi.tiw.beans.Folder;

public class PacketDocument {

	private Folder folder;
	private List<Document> documents;
	
	public PacketDocument(Folder folder, List<Document> documents){
		this.folder = folder;
		this.documents = documents;
	}
	
	public Folder getFolder(){
		return this.folder;
	}


	public List<Document> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}
}
