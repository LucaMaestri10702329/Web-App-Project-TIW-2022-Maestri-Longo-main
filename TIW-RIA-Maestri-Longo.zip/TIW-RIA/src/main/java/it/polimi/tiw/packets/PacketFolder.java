package it.polimi.tiw.packets;

import java.util.List;

import it.polimi.tiw.beans.Folder;

public class PacketFolder {

	private Folder folder;
	private List<Folder> subfolders;
	
	public PacketFolder(Folder folder, List<Folder> subfolders){
		this.folder = folder;
		this.subfolders = subfolders;
	}
	
	public Folder getFolder(){
		return this.folder;
	}

	public List<Folder> getSubfolder(){
		return this.subfolders;
	}
}
