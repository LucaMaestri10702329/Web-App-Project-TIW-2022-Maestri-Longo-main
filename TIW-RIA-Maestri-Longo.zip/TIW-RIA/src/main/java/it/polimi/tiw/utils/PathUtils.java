package it.polimi.tiw.utils;


public class PathUtils {


    public static String pathToHomePage = "/home.html";
    public static String pathToLoginPage = "/login.html";
  
}
