/**
 * Drive
 */
(function(){
    //Vars
    var userInfo, folderList, subfolderList, documentList, subFolderList;
    var subFolderId, documentId;
    var useriD;
    var documentowner;
    var folderSelected,subFolderSelected;
    var folderIdDelete, documentIdDelete;
    var pageOrchestrator = new PageOrchestrator();

    window.addEventListener("load", () => {
        pageOrchestrator.start(); // initialize the components
        pageOrchestrator.refresh(); // display initial content
    });
	function PageOrchestrator(){
        this.start = function(){
            //Init components
            userInfo = new UserInfo(
                sessionStorage.getItem('name'), 
                sessionStorage.getItem('id'), 
                [document.getElementById("userName"), document.getElementById("headerUserName")], 
                [document.getElementById("headerUserCode")], 
                document.getElementById("logout-button")
            );
             folderList = new FolderList(
                document.getElementById("create-folder-form"), 
                document.getElementById("folder-form-button"), 
                document.getElementById("create-folder-warning"), 
                document.getElementById("create-folder-button"), 
                document.getElementById("folders"), 
                document.getElementById("folders-message")
            );
            
            
            subfolderList = new SubfolderList(
                document.getElementById("folder-details"),
                document.getElementById("folder-name"),
                document.getElementById("folder-code"),
                document.getElementById("folder-balance"),
                document.getElementById("_create-subfolder-form"),
                document.getElementById("_subfolder-form-button"),
                document.getElementById("_create-subfolder-button"),
                document.getElementById("_subfolders"),
                document.getElementById("_subfolders-message")
            );
            
            documentList = new DocumentList(
                document.getElementById("document-details"),
                document.getElementById("document-name"),
                document.getElementById("account-code"),
                document.getElementById("account-balance"),
                document.getElementById("create-document-form"),
                document.getElementById("document-form-button"),
                document.getElementById("create-document-button"),
                document.getElementById("documents"),
                document.getElementById("documents-message")
            );
            
            subFolderList = new SubFolderList(
                document.getElementById("subfolder-form"), 
                document.getElementById("subfolder-form-button"), 
                document.getElementById("create-subfolder-warning"), 
                document.getElementById("create-subfolder-button"), 
                document.getElementById("subfolders"), 
                document.getElementById("subfolders-message")
            );
            
            
             
            
        };
        this.refresh = function(excludeContacts){
            //Refresh view
            userInfo.show();
            folderList.show();
           
        };
    }
    
    
    function UserInfo(
        _name, 
        _usercode, 
        nameElements, 
        codeElements, 
        _logout_button){ 

        this.name = _name;
        this.code = _usercode;
        this.logout_button = _logout_button;
		
		useriD = _usercode;
		
        this.logout_button.addEventListener("click", e => {
            sessionStorage.clear();
        });

        this.show = function(){
            nameElements.forEach(element => {
                element.textContent = this.name;
            });
            codeElements.forEach(element => {
                element.textContent = this.code;
            });
        }
       
    }
    
    function FolderList(
        _create_folder_form, 
        _folder_form_button,
        _create_folder_warning,
        _create_folder_button,
        _folders, 
        _folders_message){

        this.create_folder_form_div = _create_folder_form;
        this.folder_form_button = _folder_form_button;
        this.create_folder_warning = _create_folder_warning;
        this.create_folder_button = _create_folder_button;
        this.folders = _folders;
        this.folders_message = _folders_message;

        this.currentSelectedId = NaN;
        this.last_used_open_button = null;
        this.folder_names = [];

        var self = this; //Necessary only for in-function helpers (makeCall)
        //Link to buttons
        this.create_folder_button.addEventListener('click', (e) =>{
            var button_label = e.target.textContent;
            if(button_label === 'Create folder'){
                e.target.textContent = 'Hide form';
                self.create_folder_warning.style.display = 'none';
                self.create_folder_form_div.style.display='block';
            }else{
                e.target.textContent = 'Create folder';
                self.create_folder_form_div.style.display='none';
            }
        });

        this.folder_form_button.addEventListener("click", (e) =>{

            self.create_folder_warning.style.display = 'none';

            var create_folder_form = e.target.closest("form");
            if(create_folder_form.checkValidity()){
                
                var input_name = create_folder_form.querySelector("input[name='folderName']");
                if(self.folder_names.includes(input_name.value)){
                    create_folder_form.reset();
                    self.create_folder_warning.textContent = "Chosen folder name already exists";
                    self.create_folder_warning.style.display = 'block';
                    return;
                }

                makeCall("POST", 'CreateFolder', create_folder_form, (req) =>{
                    switch(req.status){
                        case 200: //ok
                            var click = new Event("click");
                            self.create_folder_button.dispatchEvent(click);
                            self.show();
                            break;
                        case 400: // bad request
                        case 401: // unauthorized
                        case 500: // server error
                            self.create_folder_warning.textContent = req.responseText;
                            self.create_folder_warning.style.display = 'block';
                            break;
                        default: //Error
                            self.create_folder_warning.textContent = "Request reported status " + req.status;
                            self.create_folder_warning.style.display = 'block';
                    }
                });
            }else{
                create_folder_form.reportValidity();
            }
        });

        this.show = function(){
            //Request and update with the results
            makeCall("GET", 'GetFolders', null, (req) =>{
                switch(req.status){
                    case 200: //ok
                        var folders = JSON.parse(req.responseText);
                        self.update(folders);
                        if(!isNaN(self.currentSelectedId)){
                            var open_folder_button = document.querySelector("a[data_accountid='" + self.currentSelectedId + "']");
                            var click = new Event("click");
                            if(open_folder_button)
                                open_folder_button.dispatchEvent(click);
                        } 
                        break;
                    case 400: // bad request
                    case 401: // unauthorized
                    case 500: // server error
                        self.update(null, req.responseText);
                        break;
                    default: //Error
                        self.update(null, "Request reported status " + req.status);
                        break;
                }
            });
        };
        this.update = function(_folders, _error) {
            subFolderList.hide();
            self.folders.style.display = "none";
            self.folders.innerHTML = "";
            self.folder_names.splice(0,self.folder_names.length); //Clear array

            if(_error){

                self.folders_message.textContent = _error;
                if(!self.folders_message.className.includes("warning-message"))
                    self.folders_message.className += " warning-message";
                self.folders_message.style.display = "block";
                
            }else{

                if(_folders.length === 0){
                    if(self.folders_message.className.includes("warning-message"))
                        self.folders_message.className.replace(" warning-message", "");
                    self.folders_message.textContent = "You have no folders :(";
                    self.folders_message.style.display = "block";
                }else{
                    self.folders_message.style.display = "none";
                    let card, card_title, card_data, b1, b2, br, open_button;
                    let i = 0;
                    _folders.forEach((fol) => {
                        card = document.createElement("div");
                        card.className = "card card-blue";
                        if( i % 2 === 0)
                            card.className += " even";
                        card_title = document.createElement("div");
                        card_title.className = "card-title";
                        card_title.textContent = fol.name;
                        card_title.draggable = true;
                        
                        card_title.addEventListener('dragstart', (e) =>{
							 var cest = document.getElementById("trash");
  	 						 cest.style.display = 'block';
  	 						 folderIdDelete=fol.id
  	 						 cest.draggable = true;
  	 						 cest.addEventListener('dragover', handleDragOver);
  	 						 cest.addEventListener('drop',drop_folder);
  	 						 cest.addEventListener('dragleave', handleDragLeave);
  	 						 
  	 						 });
  	 					card_title.addEventListener('dragend', handleDragEnd);
  	 						
                        
                        
                        
                        card.appendChild(card_title);
                        card_data = document.createElement("div");
                        card_data.className = "card-data";

                        b1 = document.createElement("b");
                        b1.textContent = "Code folder: ";
                        card_data.appendChild(b1);
                        card_data.appendChild(document.createTextNode(fol.id));
                    
                        br = document.createElement("br");
                        card_data.appendChild(br);

                        b2 = document.createElement("b");
                        b2.textContent = "Creation Date: ";
                        card_data.appendChild(b2);
                        card_data.appendChild(document.createTextNode(fol.date));
                        
                       
                
        



                        card.appendChild(card_data);
                        open_button = document.createElement("a");
                        open_button.className = "btn btn-purple btn-small btn-primary";
                        open_button.textContent = "Open";
                        open_button.setAttribute('data_accountid', fol.id);
                        open_button.addEventListener("click", (e) => {
                            if(e.target.textContent === "Open"){
                                if(self.last_used_open_button !== null){
                                    self.last_used_open_button.textContent = "Open";
                                }
                                e.target.textContent = "Hide";
                                self.last_used_open_button = e.target;
                                self.currentSelectedId = fol.id;
                                folderSelected = fol;
                                subfolderList.show(fol.id);
                            }else{
                                self.last_used_open_button = null;
                                self.currentSelectedId = NaN;
                                e.target.textContent = "Open";
                                subfolderList.hide();
                                subFolderList.hide();
                                documentList.hide();
                            }
                        });
                        card.appendChild(open_button);
                        self.folder_names.push(fol.name);
                        self.folders.appendChild(card);
                        i++;
                    });
                    self.folders.style.display = "block";
                }
            }
        };
    }
    
    
    function SubfolderList(
                        _folder_details,
                        _folder_name, 
                        _folder_code,
                        _folder_balance, 
                        _create_subfolder_form_div, 
                        _subfolder_form_button,
                        _create_subfolder_button,
                        _subfolders, 
                        _subfolders_message){
        //Saving vars
        this.folder_details = _folder_details;
        this.folder_name_span = _folder_name;
        this.folder_code_span = _folder_code;
        this.folder_balance_span = _folder_balance;
        this.create_subfolder_form_div = _create_subfolder_form_div;
        this.subfolder_form_button = _subfolder_form_button;
        this.create_subfolder_button = _create_subfolder_button;
        this.subfolders = _subfolders;
        this.subfolders_message = _subfolders_message;
        
        this.create_subfolder_form = this.create_subfolder_form_div.querySelector("form");
        this.dest_input = this.create_subfolder_form.querySelector("input[name='name']");
        this.folder_input = this.create_subfolder_form.querySelector("input[name='destAccountId']");
        this.amount_input = this.create_subfolder_form.querySelector("input[name='amount']");
        this.source_id = this.create_subfolder_form.querySelector("input[name='sourceAccountId']");
        
        this.currentSelectedId = NaN;
        this.last_used_open_button = null;
        var self = this;
        
        //Attach listeners
        this.create_subfolder_button.addEventListener("click", (e) => {
            if(this.create_subfolder_button.textContent === 'Create subfolder'){
                this.showCreate();
            }else{
                this.hideCreate(false); //Avoid resetting form
            }
        });
        this.subfolder_form_button.addEventListener("click", (e) =>{
            //Get form
            if(this.create_subfolder_form.checkValidity()){
                //Check account loop
                //Make request
                var self = this;
                makeCall("POST", 'CreateSubFolder', this.create_subfolder_form, (req) =>{
                    switch(req.status){
                        case 200: //ok
                           		subfolderList.show(folderSelected.id);
                        case 400: // bad request
                        case 401: // unauthorized
                        case 500: // server error
                            break;
                        default: //Error
                    }
                });
            }
        });
        
        this.showCreate = function(){
            this.create_subfolder_button.textContent = 'Hide form';
            this.create_subfolder_form_div.style.display = 'block';
        };
        this.hideCreate = function(reset){
            this.create_subfolder_button.textContent = 'Create subfolder';
            this.create_subfolder_form_div.style.display = 'none'; 
            if (reset)
                this.create_subfolder_form.reset();
        };
        this.show = function(accountID){
            //Request and update with the results
            var self = this;
            makeCall("GET", 'GetSubFolder?accountId=' + accountID, null, (req) =>{
                switch(req.status){
                    case 200: //ok
                        var data = JSON.parse(req.responseText);
                        self.update(data.folder, data.subfolders, false);
                        break;
                    case 400: // bad request
                    case 401: // unauthorized
                    case 500: // server error
                        self.update(null, req.responseText);
                        break;
                    default: //Error
                        self.update(null, "Request reported status " + req.status);
                        break;
                }
            });
        };
        this.hide = function(){
            this.folder_details.style.display = "none";
            this.hideCreate(true); //Also reset form
        };
        this.update = function(folder, subfolders, error_message){
            //Hide content while refreshing
            this.hide();
            //Init headers
            this.folder_name_span.textContent = folderSelected.name;
            //Init message
            this.subfolders_message.className = (error_message ? "warning-message" : "");
            this.subfolders_message.style.display = (error_message || subfolders.length === 0 ? "block" : "none");// invert order
            //Init hidden data
            this.source_id.value = folderSelected.id;


			
            //Clear content
            this.subfolders.innerHTML = "";
            if (error_message){
                this.subfolders_message.textContent = error_message;
                this.subfolder_details.style.display = "block";
                return;
            }else if (subfolders.length === 0){
                this.subfolders_message.textContent = "You have no subfolder for this folder :(";
                this.folder_details.style.display = "block";
                return;
            }
            
            //Init list   
            subfolders.forEach((subfolder) => {
				
                let card, card_title, card_data, b1, br, b2, amount_div;

                card = document.createElement("div");
                card.className = "linked-card linked-card-blue";

                card_title = document.createElement("div");
                card_title.className = "linked-card-title";
                card_title.textContent = (subfolder.name);
                
                card_title.addEventListener('dragstart', (e) =>{
							 var cest = document.getElementById("trash");
  	 						 cest.style.display = 'block';
  	 						 folderIdDelete=acc.id
  	 						 cest.draggable = true;
  	 						 cest.addEventListener('dragover', handleDragOver);
  	 						 cest.addEventListener('drop',drop_folder);
  	 						 cest.addEventListener('dragleave', handleDragLeave);
  	 						 
  	 						 });
  	 					
  	 					card_title.addEventListener('dragend', handleDragEnd);
                
                card.appendChild(card_title);
                
                card_data = document.createElement("div");
                card_data.className = "linked-card-data";
                
				b1 = document.createElement("b");
                b1.textContent = "Code folder: ";
                card_data.appendChild(b1);
                card_data.appendChild(document.createTextNode(subfolder.id));
                
                br = document.createElement("br");
                card_data.appendChild(br);
                
                b1 = document.createElement("b");
                b1.textContent = "Data creation: ";
                card_data.appendChild(b1);
                card_data.appendChild(document.createTextNode(subfolder.date));
                    
                br = document.createElement("br");
                card_data.appendChild(br);
				   open_button = document.createElement("a");
                        
                        open_button.textContent = "Open";
                        open_button.setAttribute("folderId",subfolder.id);
                       	open_button.addEventListener("click", (e) => {
                            if(e.target.textContent === "Open"){
                                if(self.last_used_open_button !== null){
                                    self.last_used_open_button.textContent = "Open";
                                }
                                e.target.textContent = "Hide";
                                self.last_used_open_button = e.target;
                                subFolderSelected =  subfolder;
                                documentList.show(subfolder.id);
                            }else{
                                self.last_used_open_button = null;
                             
                                e.target.textContent = "Open";
                                documentList.hide();
                            }
                        });
                card.appendChild(open_button);
                
                
                card.appendChild(card_data);
                
               
                this.subfolders.appendChild(card);
           
            });
            this.folder_details.style.display = "block";
        };
    }
     function DocumentList(
                        _folder_details,
                        _folder_name, 
                        _folder_code,
                        _folder_balance, 
                        _create_document_form_div, 
                        _document_form_button,
                        _create_document_button,
                        _documents, 
                        _documents_message){
        //Saving vars
       this.folder_details = _folder_details;
        this.folder_name_span = _folder_name;
        this.folder_code_span = _folder_code;
        this.folder_balance_span = _folder_balance;
        this.create_document_form_div = _create_document_form_div;
        this.document_form_button = _document_form_button;
        this.create_document_button = _create_document_button;
        this.documents = _documents;
        this.documents_message = _documents_message;
        
        this.create_document_form = this.create_document_form_div.querySelector("form");
        this.dest_input = this.create_document_form.querySelector("input[name='name']");
        this.account_input = this.create_document_form.querySelector("input[name='destAccountId']");
        this.amount_input = this.create_document_form.querySelector("input[name='amount']");
        this.source_id = this.create_document_form.querySelector("input[name='sourceAccountId']");
        
        this.currentSelectedId = NaN;
        this.last_used_open_button = null;
        var self = this;
        
        //Attach listeners
        this.create_document_button.addEventListener("click", (e) => {
            if(this.create_document_button.textContent === 'Create document'){
                this.showCreate();
            }else{
                this.hideCreate(false); //Avoid resetting form
            }
        });
        this.document_form_button.addEventListener("click", (e) =>{
            //Get form
            if(this.create_document_form.checkValidity()){
	
				//var input_name = create_document_form.querySelector("input[name='documentName']");
                //if(self.folder_names.includes(input_name.value)){
                //    create_folder_form.reset();
                //    self.create_folder_warning.textContent = "Chosen folder name already exists";
                //    self.create_folder_warning.style.display = 'block';
                //    return;
                //}
               
                //Make request
                var self = this;
                makeCall("POST", 'CreateDocument', this.create_document_form, (req) =>{
                    switch(req.status){
                        case 200: //ok
                            documentList.show(subFolderSelected.id);
                        case 400: // bad request
                        case 401: // unauthorized
                        case 500: // server error
                            break;
                        default: //Error
                    }
                });
            }
        });
        
        this.showCreate = function(){
            this.create_document_button.textContent = 'Hide form';
            this.create_document_form_div.style.display = 'block';
        };
        this.hideCreate = function(reset){
            this.create_document_button.textContent = 'Create document';
            this.create_document_form_div.style.display = 'none'; 
            if (reset)
                this.create_document_form.reset();
        };
        this.show = function(accountID){
            //Request and update with the results
            var self = this;
            console.log("Qui arrivo");
            makeCall("GET", 'GetDocuments?accountId=' + accountID, null, (req) =>{
                switch(req.status){
                    case 200: //ok
                        var data = JSON.parse(req.responseText);
                        self.update(data.folder, data.documents, false);
                        break;
                    case 400: // bad request
                    case 401: // unauthorized
                    case 500: // server error
                        self.update(null, req.responseText);
                        break;
                    default: //Error
                        self.update(null, "Request reported status " + req.status);
                        break;
                }
            });
        };
        this.hide = function(){
            this.folder_details.style.display = "none";
            this.hideCreate(true); //Also reset form
        };
        this.update = function(folder, documents, error_message){
            //Hide content while refreshing
            this.hide();
            //Init headers
            this.folder_name_span.textContent = folder.name
            //Init message
            this.documents_message.className = (error_message ? "warning-message" : "");
            this.documents_message.style.display = (error_message || documents.length === 0 ? "block" : "none");// invert order
            //Init hidden data
            this.source_id.value = folder.id;
            documentowner = folder.id;

			
			
            //Clear content
            this.documents.innerHTML = "";
            if (error_message){
                this.documents_message.textContent = error_message;
                this.folder_details.style.display = "block";
                return;
            }else if (documents.length === 0){
                this.documents_message.textContent = "You have no document for this folder :(";
                this.folder_details.style.display = "block";
                return;
            }
            
            //Init list   
            documents.forEach((doc) => {

                let card, card_title, card_data, b1, br, b2, amount_div;

                card = document.createElement("div");
                card.className = "linked-card linked-card-blue";

                card_title = document.createElement("div");
                card_title.className = "linked-card-title";
                card_title.textContent = (doc.name);
                card_title.draggable = true;
               
               
                card_title.addEventListener('dragstart', (e) =>{
					//this.style.opacity = '0.4';
  	 				subFolderList.show(1);
  	 				documentId=doc.id
  	 				
  	 				 var cest = document.getElementById("trash");
  	 						 cest.style.display = 'block';
  	 						 documentIdDelete=doc.id
  	 						 cest.draggable = true;
  	 						 cest.addEventListener('dragover', handleDragOver);
  	 						 cest.addEventListener('drop',drop_document);
  	 						 cest.addEventListener('dragleave', handleDragLeave);
  	 				
  	 				});    
  	 				
  	 				
  	 				
  	 				
                  
  				card_title.addEventListener('dragend', handleDragEnd);
                card.appendChild(card_title);
                
          
                
                card_data = document.createElement("div");
                card_data.className = "linked-card-data";

                b1 = document.createElement("b");
                b1.textContent = "Data creation: ";
                card_data.appendChild(b1);
                card_data.appendChild(document.createTextNode(doc.date));
                
                card_data = document.createElement("div");
                card_data.className = "linked-card-data";
                
                b1 = document.createElement("b");
                b1.textContent = "Document code: ";
                card_data.appendChild(b1);
                card_data.appendChild(document.createTextNode(doc.id));
                
                br = document.createElement("br");
                card_data.appendChild(br);

	            b2 = document.createElement("b");
	            b2.textContent = "Summary: ";
	            card_data.appendChild(b2);
	            card_data.appendChild(document.createTextNode(doc.summary));
                
                br = document.createElement("br");
            	card_data.appendChild(br);

                b2 = document.createElement("b");
                b2.textContent = "Type: ";
                card_data.appendChild(b2);
                card_data.appendChild(document.createTextNode(doc.type));
                
                
				 
                
                
                card.appendChild(card_data);

                this.documents.appendChild(card);
            });
            this.folder_details.style.display = "block";
        };
    }

function SubFolderList(
        _create_subfolder_form, 
        _subfolder_form_button,
        _create_subfolder_warning,
        _create_subfolder_button,
        _subfolders, 
        _subfolders_message){

        this.create_subfolder_form_div = _create_subfolder_form;
        this.subfolder_form_button = _subfolder_form_button;
        this.create_subfolder_warning = _create_subfolder_warning;
        this.create_subfolder_button = _create_subfolder_button;
        this.subfolders = _subfolders;
        this.subfolders_message = _subfolders_message;

        this.currentSelectedId = NaN;
        this.last_used_open_button = null;
        this.subfolder_names = [];

        var self = this; //Necessary only for in-function helpers (makeCall)
        //Link to buttons
        

       
 		this.showCreate = function(){
            this.create_subfolder_button.textContent = 'Hide form';
            this.create_subfolder_form_div.style.display = 'block';
            this.subfolders.style.display = 'block';
        };
        this.hideCreate = function(reset){
            
            this.create_subfolder_form_div.style.display ='block';
            this.subfolders.display = 'none';
           
        };
        
         this.hide = function(){
			this.create_subfolder_form_div.style.display='none';
            this.subfolders.style.display = "none";
            this.hideCreate(true); //Also reset form
        };
        
        this.show = function(){
            //Request and update with the results
            makeCall("GET", 'GetSubFolders', null, (req) =>{
                switch(req.status){
                    case 200: //ok
                        var subfolders = JSON.parse(req.responseText);
                        self.update(subfolders);
                        if(!isNaN(self.currentSelectedId)){
                            var open_subfolder_button = document.querySelector("a[data_accountid='" + self.currentSelectedId + "']");
                            var click = new Event("click");
                            if(open_subfolder_button)
                                open_subfolder_button.dispatchEvent(click);
                            else 
                            	console.log("Errore");    
                        } 
                        break;
                    case 400: console.log("Errore");    // bad request
                    case 401: console.log("Errore");    // unauthorized
                    case 500: console.log("Errore");    // server error
                        self.update(null, req.responseText);
                        break;
                    default: console.log("Errore");    //Error
                        self.update(null, "Request reported status " + req.status);
                        break;
                }
            });
        };
        
        this.update = function(_subfolders, _error) {
          
            self.subfolders.style.display = "none";
            self.subfolders.innerHTML = "";
            self.subfolder_names.splice(0,self.subfolder_names.length); //Clear array

            if(_error){

                self.subfolders_message.textContent = _error;
                if(!self.subfolders_message.className.includes("warning-message"))
                    self.subfolders_message.className += " warning-message";
                self.subfolders_message.style.display = "block";
                
            }else{

                if(_subfolders.length === 0){
                    if(self.subfolders_message.className.includes("warning-message"))
                        self.subfolders_message.className.replace(" warning-message", "");
                    self.subfolders_message.textContent = "You have no accounts in our bank :(";
                    self.subfolders_message.style.display = "block";
                }else{
                    
                    let card, card_title, card_data, b1, b2, br, open_button;
                    let i = 0;
                    _subfolders.forEach((acc) => {
						if(documentowner != acc.id) {
	                        card = document.createElement("div");
	                        card.className = "card card-blue";
	                        if( i % 2 === 0)
	                            card.className += " even";
	                        card_title = document.createElement("div");
	                        card_title.className = "card-title";
	                        card_title.textContent = acc.name;
	                        
		                    card_title.draggable = true;
		                	
		  					card_title.addEventListener('dragover', handleDragOver);
		  					card_title.addEventListener('dragstart',handleDragStart);
		  					card_title.addEventListener('dragLeave', handleDragLeave);
		  					card_title.addEventListener('dragend', handleDragEnd);
		  					card_title.addEventListener('drop', (e) =>{
								console.log("Qui arrivo per il drop");
							subFolderId=acc.id;
							e.preventDefault();
							makeCall("POST", 'MoveDocument?folderId='+subFolderId+'&idDocument='+documentId, null, (req) =>{
			                    switch(req.status){
			                        case 200: //ok
			                           		documentList.hide();
			                           		documentList.show();
			                            break;
			                        case 400: // bad request
			                        case 401: // unauthorized
			                        case 500: // server error
			                           
			                            break;
			                        default: //Error
			                           
	                			}
                			});
	  	 				
	  	 					});    
		  					
		  					
	                        card.appendChild(card_title);
	                        card_data = document.createElement("div");
	                        card_data.className = "card-data";
							
	                		
	
	                        card.appendChild(card_data);
	                        
	                        self.subfolder_names.push(acc.name);
	                        self.subfolders.appendChild(card);
	                        i++;
                        }
                    });
                    self.subfolders.style.display = "block";
                }
            }
        };
    }



   function handleDragOver(e) {
  	 this.style.opacity = '0.4';
  	 e.preventDefault();
  	 
}
	function handleDragLeave(e)
	{
		e.preventDefault();
		this.style.opacity = '1';
	
  	    
	}



     function handleDragStart(e) {
  	 this.style.opacity = '0.4';
  	 var cest = document.getElementById("trash");
  	 cest.style.display = 'block';
  
	}
	
	function handleDragEnd(e) {
	     this.style.opacity = '1';
	     subFolderList.hide();
	     //console.log("Qui arrivo per l'end'");
	     //var cest = document.getElementById("trash");
  	     //var cest2 = document.getElementById("trash-document");
	     //cest.style.display = 'none';
	     //cest2.style.display = 'none';	
	}
	
	function drop_folder(event)
	{
		console.log("Qui arrivo per il drop folder");
		var trash_form = document.getElementById("trash_folder_form");
		var trash_form_document = document.getElementById("trash_document_form");
		var cest = document.getElementById("trash");
		trash_form.style.display = 'block';
		trash_form_document.style.display = 'none';
		var button_yes = document.getElementById("yes");
		var button_no = document.getElementById("no");
		var container = document.getElementById("container");
		container.style.display = 'none';
		
		button_no.addEventListener("click", e =>{
			trash_form.style.display = 'none';
			cest.style.display = 'none';
			container.style.display = 'block';
		});
		button_yes.addEventListener("click", e =>{
			trash_form.style.display = 'none';
			cest.style.display = 'none';
			container.style.display = 'block';
			
			makeCall("POST", 'DeleteFolder?sourceAccountId='+folderIdDelete, null, (req) =>{
		                    switch(req.status){
		                        case 200: //ok
		                        	console.log("FOLDER ELIMINATO");
		                        	folderList.update();
		                        	subfolderList.hide();
		                        	documentList.hide();
                            		folderList.show();
		                            break;
		                        case 400: // bad request
		                        case 401: // unauthorized
		                        case 500: // server error
		                           
		                            break;
		                        default: //Error
		                           
	                }});
			//folderList.show();
			
		});
	}
	
	function drop_document(event)
	{
		console.log("Qui arrivo per il drop document");
		var trash_form = document.getElementById("trash_document_form");
		var trash_folder_form = document.getElementById("trash_folder_form");
		var cest = document.getElementById("trash-document");
		trash_form.style.display = 'block';
		trash_folder_form.style.display = 'none';
		var button_yes = document.getElementById("yes-document");
		var button_no = document.getElementById("no-document");
		var container = document.getElementById("container");
		container.style.display = 'none';
		
		button_no.addEventListener("click", e =>{
			trash_form.style.display = 'none';
			cest.style.display = 'none';
			container.style.display = 'block';
		});
		button_yes.addEventListener("click", e =>{
			trash_form.style.display = 'none';
			cest.style.display = 'none';
			container.style.display = 'block';
			
			makeCall("POST", 'DeleteDocument?documentId='+documentIdDelete, null, (req) =>{
		                    switch(req.status){
		                        case 200: //ok
		                        		 documentList.hide();
		                            break;
		                        case 400: // bad request
		                        case 401: // unauthorized
		                        case 500: // server error
		                           
		                            break;
		                        default: //Error
		                           
	                }});
			
		});
	}
	
	
    
})(); 