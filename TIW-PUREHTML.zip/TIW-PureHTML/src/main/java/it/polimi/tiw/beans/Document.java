package it.polimi.tiw.beans;

import java.io.Serializable;
import java.sql.Date;

public class Document implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String name;
	private Date date;
	private String description;
	private String type;
	private int idFolder;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getIdFolder() {
		return idFolder;
	}
	public void setIdFolder(int idFolder) {
		this.idFolder = idFolder;
	}

}
