package it.polimi.tiw.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import it.polimi.tiw.beans.Account;


public class AccountDAO {

	private Connection connection;
	public AccountDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public AccountDAO(Connection con) {
		this.connection = con;
	}
	
	public Account getAccountById(int id) throws SQLException{

		Account account = null;
		String performedAction = " finding an account by id";
		String query = "SELECT * FROM drive.account WHERE id = ?";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, id);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				account = new Account();
				account.setId(resultSet.getInt("id"));
				account.setUserId(resultSet.getInt("userid"));
				account.setName(resultSet.getString("name"));
			}
			
		}catch(SQLException e) {
			throw new SQLException("Error accessing the DB when" + performedAction);
		}finally {
			try {
				resultSet.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the result set when" + performedAction);
			}
			try {
				preparedStatement.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the statement when" + performedAction);
			}
		}
		return account;
	}
	public List<Account> getAccountsByUserId(int userid) throws SQLException{

		List<Account> accounts = new ArrayList<>();
		String performedAction = " finding accounts by user id";
		String query = "SELECT * FROM drive.account WHERE userid = ? ORDER BY id ASC";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, userid);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				Account account = new Account();
				account.setId(resultSet.getInt("id"));
				account.setUserId(resultSet.getInt("userid"));
				account.setName(resultSet.getString("name"));
				accounts.add(account);
			}
			
		}catch(SQLException e) {
			throw new SQLException("Error accessing the DB when" + performedAction);
		}finally {
			try {
				resultSet.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the result set when" + performedAction);
			}
			try {
				preparedStatement.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the statement when" + performedAction);
			}
		}
		return accounts;
	}
	public Account getAccountByUserIdAndName(int userid, String name) throws SQLException{

		Account account = null;
		String performedAction = " finding accounts by user id and account name";
		String query = "SELECT * FROM drive.account WHERE userid = ? AND name = ?";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, userid);
			preparedStatement.setString(2, name);
			resultSet = preparedStatement.executeQuery();
			
			while(resultSet.next()) {
				account = new Account();
				account.setId(resultSet.getInt("id"));
				account.setUserId(resultSet.getInt("userid"));
				account.setName(resultSet.getString("name"));
			}
			
		}catch(SQLException e) {
			throw new SQLException("Error accessing the DB when" + performedAction);
		}finally {
			try {
				resultSet.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the result set when" + performedAction);
			}
			try {
				preparedStatement.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the statement when" + performedAction);
			}
		}
		return account;
	}
public void createAccount(int userid, String name) throws SQLException {
		
		String performedAction = " creating a new bank account in the database";
		String queryAddUser = "INSERT INTO drive.account (userid,name) VALUES(?,?)";
		PreparedStatement preparedStatementAddUser = null;	
		
		try {
			
			preparedStatementAddUser = connection.prepareStatement(queryAddUser);
			preparedStatementAddUser.setInt(1, userid);
			preparedStatementAddUser.setString(2, name);
			preparedStatementAddUser.executeUpdate();
			
		}catch(SQLException e) {
			throw new SQLException("Error accessing the DB when" + performedAction);
		}finally {
			try {
				preparedStatementAddUser.close();
			}catch (Exception e) {
				throw new SQLException("Error closing the statement when" + performedAction);
			}
		}
	}
}
	